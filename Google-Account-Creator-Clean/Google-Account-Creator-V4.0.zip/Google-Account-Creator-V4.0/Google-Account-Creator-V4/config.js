module.exports = {
    usernameproxy: "lukasderonzier",
    passwordproxy: "4K9ej6jg73",
    accountNumber : 15,
    accountFile : "./accounts.csv",
    exchangeFile : "./communication.txt",
    proxyFile : "proxies.txt",
    useProxies : true,
    createYoutube : true,
    createTwitter : false,
    createTiktokWithGoogle : false,
    createTiktokWithTwitter : false
  };
  