const path = require('path')
const scriptName = path.basename(__filename)

const {executablePath} = require('puppeteer')

const express = require('express')
const {spawn} = require('child_process');

const puppeteer = require('puppeteer-extra')
const proxyloader = require('puppeteer-page-proxy');
const pluginStealth = require('puppeteer-extra-plugin-stealth')()

const getLastLine = require('./fileTools.js').getLastLine
const config = require("./config")
const fs = require('fs')
const readline = require('readline')

var ncp = require('node-clipboardy');

//-----------------------------------------------------------------------------------------------------------------------------------------
//  GLOBALS

const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

const gender = [
  "Male",
  "Female"
]

firstnames = []
lastnames  = []
useragents = []

//-----------------------------------------------------------------------------------------------------------------------------------------
//  CLASS

class Account {
    constructor(email = "", firstname = "", lastname = "", password="") {
      this.email = email;
      this.firstname = firstname;
      this.lastname = lastname;
      this.password = password;
    }
  
    saveAsCSV() {
      const csv = `${this.email}:${this.password}:${this.firstname}:${this.lastname}\n`;
      try {
        fs.appendFileSync(config.accountFile, csv);
      } catch (err) {
        console.error(err);
      }
    }
}
  
  class Proxy {
    constructor(ip = "", port = "", username = "", password = "") {
      this.port = port;
      this.ip = ip;
      this.username = username;
      this.password = password;
    }
}
  
//-----------------------------------------------------------------------------------------------------------------------------------------
//  FUNCTIONS


function sleep(time) {
  return new Promise(function(resolve) { 
      setTimeout(resolve, time)
  });
}

function generate_proxies() {
    proxies = []
    /*const content = fs.readFileSync(config.proxyFile).toString();
  
    content.split(/([{}])/).filter(Boolean).forEach(e =>
    e == '{' ? c++ : e == '}' ? c-- : c > 0 ? array.push(e) : array.push(e)
    );
  
    for (var i = 0; i < array.length-1; i+=2){
      subarray = [];
      array[i].split(/([,,])/).filter(Boolean).forEach(e =>
        e == ',' ? c++ : e == ',' ? c-- : c > 0 ? subarray.push(e) : subarray.push(e)
      );
  
      let ip = subarray[2].split(":")[1];
      let port = subarray[3].split(":")[1];
  
      ip = ip.replace(/["]/g,'')
  
      const proxy = new Proxy(ip, port, config.usernameproxy, config.passwordproxy);
      proxies.push(proxy);
    }*/

    const text_lastnames = readline.createInterface({
      input: fs.createReadStream('proxies.txt'),
      output: process.stdout,
      terminal: false
    });
      
    text_lastnames.on('line', (line) => {
      array = line.split(":")
      const proxy = new Proxy('95.179.225.113', array[2], config.usernameproxy, config.passwordproxy);
      proxies.push(proxy)
    });

    return proxies;
}

function generate_accounts() {
  accounts = []
  const text_accounts = readline.createInterface({
    input: fs.createReadStream(config.accountFile),
    output: process.stdout,
    terminal: false
  });
    
  text_accounts.on('line', (line) => {
      splitted = line.split(':')
      var account = new Account(splitted[0], splitted[1]);
      accounts.push(account)
  });

  return accounts
}

function generate_names() {

  const text_firstnames = readline.createInterface({
    input: fs.createReadStream('names.txt'),
    output: process.stdout,
    terminal: false
  });
    
  text_firstnames.on('line', (line) => {
      firstnames.push(line)
  });

  const text_lastnames = readline.createInterface({
    input: fs.createReadStream('lastnames.txt'),
    output: process.stdout,
    terminal: false
  });
    
  text_lastnames.on('line', (line) => {
      lastnames.push(line)
  });
}

function generate_useragents() {

  const text = readline.createInterface({
    input: fs.createReadStream('useragents.txt'),
    output: process.stdout,
    terminal: false
  });
    
  text.on('line', (line) => {
      useragents.push(line)
  });
}

function makeid(length) {   // Generates a random character string composed of [length] characters picked randomly from the set [a-zA-Z0-9].
  let result = '';
  const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

function communicate(text) {
  const add = text + "\n";
  try {
    fs.appendFileSync(config.exchangeFile, add);
  } catch (err) {
    console.error(err);
  }
}

async function tryClick(page, selector, type, wait = 1000, critical = false)
{
  if (type === 0 && await page.$(selector) !== null)
  {
      await page.click(selector)
      await sleep(wait)
  }
  else if (type === 1)
  {
      const button = await (await page.evaluateHandle(selector)).asElement();
      if (button != null) button.click();
      await sleep(wait)
  }
  else if (critical === true)
  {
      console.log("[LEGION]: Critical element not found. Aborting.");
      await page.close()
  }
}

//-----------------------------------------------------------------------------------------------------------------------------------------
//  MAIN

async function main() {

  const proxies = generate_proxies();

  generate_names();
  generate_useragents();

  fs.writeFile(config.exchangeFile, '', (err) => {
    if (err) throw err;
  });
  
  puppeteer.use(pluginStealth)

  for (let i = 0; i < config.accountNumber; i++) 
  {
    const python = spawn('python', ['main.py']);
    await sleep(1000);

    var browser = await puppeteer.launch({
      headless: false,
      executablePath: 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
      args: [
        "--start-maximized"
      ],
    })

    var deadAccount = await browser.newPage();
    deadAccount.goto('https://temp-mail.org/fr/');

    const context = browser.defaultBrowserContext()
    context.overridePermissions('https://twitter.com/search?source=desktop-search&q=%7BsearchTerms%7D', ['clipboard-read', 'clipboard-write'])

    var [page] = await browser.pages()
    await page.close()
    page = await browser.newPage()
    
    await page.setViewport({ width: 1366, height: 768});
    await page.evaluateOnNewDocument(() => {
      delete navigator.__proto__.webdriver;
    });

    if (config.useProxies)
    {
      var currentProxy = 'http://lukasderonzier:4K9ej6jg73@'+ proxies[Math.floor(i/4)].ip +':'+ proxies[Math.floor(i/4)].port
      await proxyloader(page, currentProxy);
      console.log("[LEGION]:Proxy activated.");
    }
  
    await page.setUserAgent(
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.79 Safari/537.36"
    );

    await sleep(1000);

    // CREATE NEW ACCOUNT ID

    var firstname = firstnames[Math.floor(Math.random()*firstnames.length)]
    var lastname = lastnames[Math.floor(Math.random()*lastnames.length)]

    const account = new Account(firstname+"."+lastname+makeid(5), firstname, lastname, makeid(10));

    // GO TO ACCOUNT CREATE PAGE

    if (config.createYoutube)
    {
      await page.goto(
        "https://www.youtube.com"
      );

      await page.waitForTimeout(2000);

      if (await page.$("#topbar > div.top-buttons.style-scope.ytd-consent-bump-v2-lightbox > div:nth-child(2) > ytd-button-renderer > yt-button-shape > a > yt-touch-feedback-shape > div > div.yt-spec-touch-feedback-shape__fill") !== null)
      {
        console.log("found");
        await page.waitForTimeout(1000);
        await page.click("#topbar > div.top-buttons.style-scope.ytd-consent-bump-v2-lightbox > div:nth-child(2) > ytd-button-renderer > yt-button-shape > a > yt-touch-feedback-shape > div > div.yt-spec-touch-feedback-shape__fill");
      }
      else 
        console.log("not found");

      await page.waitForTimeout(2000);
      //await page.click("#yDmH0d > c-wiz > div > div.eKnrVb > div > div.Z6Ep7d > div > div.XOrBDc > div > div > div:nth-child(1) > div > button > span");
      await tryClick(page, 'document.querySelector("#yDmH0d > c-wiz > div > div.eKnrVb > div > div.Z6Ep7d > div > div.XOrBDc > div > div > div:nth-child(1) > div > button > span")', 1)
      await tryClick(page, 'document.querySelector("#yDmH0d > c-wiz > div > div.eKnrVb > div > div.Z6Ep7d > div > div.XOrBDc > div > div > div:nth-child(2) > div > ul > li:nth-child(2)")', 1)
      //await page.waitForTimeout(2000);
      //await tryClick(page, 'document.querySelector("#yDmH0d > c-wiz > div > div.eKnrVb > div > div.Z6Ep7d > div > div.XOrBDc > div > div > div:nth-child(1) > div > button > span")', 1)
      await page.waitForTimeout(2000);

      // FILL ACCOUNT INFO

      await page.waitForSelector("#firstName");
      await page.type("#firstName", account.firstname, { delay: 400 });
      await page.waitForTimeout(2000);
      await page.keyboard.press("Enter");

      await page.waitForSelector("#lastName");
      await page.type("#lastName", account.lastname, { delay: 400 });
      await page.waitForTimeout(2000);
      await page.keyboard.press("Enter");

      await page.waitForTimeout(2000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.WEQkZc > div > form > span > section > div > div > div.akwVEf.OcVpRe > div:nth-child(3) > div > div > button > span");

      await page.waitForSelector("#username");
      await page.type("#username", account.email, { delay: 400 });
      await page.waitForTimeout(2000);
      await page.keyboard.press("Enter");

      await page.waitForSelector("#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input");
      await page.type("#passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input", account.password, { delay: 400 });
      await page.waitForTimeout(2000);
      await page.keyboard.press("Enter");

      await page.waitForSelector("#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input");
      await page.type("#confirm-passwd > div.aCsJod.oJeWuf > div > div.Xb9hP > input", account.password, { delay: 400 });
      await page.waitForTimeout(2000);
      await page.keyboard.press("Enter");

      await page.waitForTimeout(2000);

      // GET PHONE NUMBER 

      await page.waitForTimeout(2000);
      communicate("REQUIRE_NUMBER");

      getNumber = true;
      getCode = true;

      number = 0;
      code = 0;
      i = 0
      while (getNumber)
      {
        await sleep(2000);

        var call = "";
        await getLastLine(config.exchangeFile, 1)
            .then((lastLine)=> {
                call = lastLine
                console.log(call)
            })
            .catch((err)=> {
                console.error(err)
            })

        number = parseInt(call) || 0;
        console.log(number);
        if (number != 0)
        {
          getNumber = false;
        }
      }

      await page.waitForTimeout(2000);
      await page.waitForSelector("#phoneNumberId");
      await page.type("#phoneNumberId", number.toString(), { delay: 400 });

      await page.waitForTimeout(1000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button > div.VfPpkd-RLmnJb");

      // GET CODE

      await page.waitForTimeout(2000);
      communicate("REQUIRE_CODE");

      while (getCode)
      {
        await sleep(2000);

        var call = "";
        await getLastLine(config.exchangeFile, 1)
            .then((lastLine)=> {
                call = lastLine
                console.log(call)
            })
            .catch((err)=> {
                console.error(err)
            })

        code = parseInt(call) || 0;
        console.log(code);
        if (code != 0)
        {
          getCode = false;
        }
      }

      var codeFinal = code.toString()
      while (codeFinal.length < 6) codeFinal = "0" + codeFinal;

      await page.waitForTimeout(2000);
      await page.waitForSelector("#code");
      await page.type("#code", codeFinal, { delay: 400 });

      await page.keyboard.press("Enter");
      await page.waitForTimeout(1000);

      // SAVE ACCOUNT DATA

      account.saveAsCSV();

      // ADD USER INFO

      await page.waitForSelector("#day");
      await page.type("#day", ((Math.floor(Math.random() * 18)+1)+10).toString(), { delay: 400 });
      await page.waitForTimeout(1000);

      await page.waitForSelector("#year");
      await page.type("#year", (2002-(Math.floor(Math.random() * 40) + 1)).toString(), { delay: 400 });
      await page.waitForTimeout(1000);

      await page.select('#month', (Math.floor(Math.random() * 12)+1).toString())
      await sleep(1000);

      await page.select('#gender', (Math.floor(Math.random() * 2)+1).toString())
      await sleep(1000);

      await page.keyboard.press("Enter");
      await page.waitForTimeout(1000);

      // EXPRESS CUSTOM

      await page.waitForTimeout(2000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div.dG5hZc > div.daaWTb > div > div > button > span");

      await page.waitForTimeout(2000);
      await page.click("#selectionc11");

      await page.waitForTimeout(2000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div > div > div > button > div.VfPpkd-RLmnJb");

      await page.waitForTimeout(2000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3.F8PBrb > div > div > div:nth-child(2) > div > div > button > span");

      await page.waitForTimeout(2000);
      await page.click("#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button > span");
    }

    if (config.createTwitter)
    {
      await sleep(1000);
      await page.goto("https://twitter.com/search?source=desktop-search&q=%7BsearchTerms%7D")

      await sleep(1000);
      await tryClick(deadAccount, '#tm-body > div.section-top-qr > div > div > div.col-xs-12.col-sm-12.col-md-12.col-lg-12.col-xl-6 > div.temp-emailbox > form > div.input-box-col.hidden-xs-sm > button > svg', 0)

      await sleep(1000);
      await tryClick(page, '#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-1kihuf0.r-18u37iz.r-1pi2tsx.r-1777fci.r-1pjcn9w.r-xr3zp9.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-14lw9ot.r-1867qdf.r-1jgb5lz.r-pm9dpa.r-1ye8kvj.r-1rnoaur.r-13qz1uu > div > div.css-1dbjc4n.r-1h3ijdo.r-136ojw6 > div > div > div > div.css-1dbjc4n.r-1habvwh.r-1pz39u2.r-1777fci.r-15ysp7h.r-s8bhmr > div > div > svg', 0)

      await tryClick(page, '#react-root > div > div > div.css-1dbjc4n.r-18u37iz.r-13qz1uu.r-417010 > main > div > div > div > div.css-1dbjc4n.r-aqfbo4.r-zso239.r-1hycxz > div > div.css-1dbjc4n.r-gtdqiz.r-1hycxz > div > div > div > div:nth-child(1) > section > div.css-1dbjc4n.r-1ifxtd0.r-19u6a5r.r-1b7u577.r-1wzrnnt > a > div', 0)

      await page.waitForSelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div:nth-child(2) > div:nth-child(1) > label > div > div.css-1dbjc4n.r-18u37iz.r-16y2uox.r-1wbh5a2.r-1wzrnnt.r-1udh08x.r-xd6kpl.r-1pn2ns4.r-ttdzmv > div > input");
      await page.type("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div:nth-child(2) > div:nth-child(1) > label > div > div.css-1dbjc4n.r-18u37iz.r-16y2uox.r-1wbh5a2.r-1wzrnnt.r-1udh08x.r-xd6kpl.r-1pn2ns4.r-ttdzmv > div > input", account.firstname+account.lastname, { delay: 400 });
      await sleep(1000);

      await page.waitForSelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div:nth-child(2) > div:nth-child(2) > label > div > div.css-1dbjc4n.r-18u37iz.r-16y2uox.r-1wbh5a2.r-1wzrnnt.r-1udh08x.r-xd6kpl.r-1pn2ns4.r-ttdzmv > div > input");
      await page.type("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div:nth-child(2) > div:nth-child(2) > label > div > div.css-1dbjc4n.r-18u37iz.r-16y2uox.r-1wbh5a2.r-1wzrnnt.r-1udh08x.r-xd6kpl.r-1pn2ns4.r-ttdzmv > div > input", ncp.readSync(), { delay: 400 });
      await sleep(1000);

      await page.select('#SELECTOR_1', (Math.floor(Math.random() * 12)+1).toString())
      await sleep(1000);

      await page.select('#SELECTOR_2', (Math.floor(Math.random() * 29)+1).toString())
      await sleep(1000);

      await page.select('#SELECTOR_3', ('2000'))
      await sleep(1000);

      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-1isdzm1 > div > div > div > div > div")', 1)

      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div > label:nth-child(3) > div:nth-child(2) > label > div > div > div")', 1)
      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div > label:nth-child(5) > div:nth-child(2) > label > div > div > div")', 1)
      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1dqxon3 > div > div > label:nth-child(7) > div:nth-child(2) > label > div > div > div")', 1)

      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-9hvr93.r-1isdzm1 > div > div > div > div > div")', 1)

      await tryClick(page, 'document.querySelector("#layers > div:nth-child(2) > div > div > div > div > div > div.css-1dbjc4n.r-1awozwy.r-18u37iz.r-1pi2tsx.r-1777fci.r-1xcajam.r-ipm5af.r-g6jmlv > div.css-1dbjc4n.r-1867qdf.r-1wbh5a2.r-kwpbio.r-rsyp9y.r-1pjcn9w.r-1279nm1.r-htvplk.r-1udh08x > div > div > div.css-1dbjc4n.r-14lw9ot.r-6koalj.r-16y2uox.r-1wbh5a2 > div.css-1dbjc4n.r-16y2uox.r-1wbh5a2.r-1jgb5lz.r-1ye8kvj.r-13qz1uu > div.css-1dbjc4n.r-1isdzm1 > div > div > div.css-1dbjc4n.r-pw2am6 > div > div")', 1)
    }

    if (config.createTiktokWithTwitter)
    {
      await sleep(1000);
      await page.goto("https://www.tiktok.com/")

      await tryClick(page, '#login-modal > div.tiktok-unxpj7-DivCloseWrapper.e1gjoq3k4 > svg', 0)
      await tryClick(page, 'document.querySelector("body > tiktok-cookie-banner").shadowRoot.querySelector("div > div.button-wrapper > button:nth-child(2)")', 1)

      await tryClick(page, '#app > div.tiktok-xk7ai4-DivHeaderContainer.e10win0d0 > div > div.tiktok-ba55d9-DivHeaderRightContainer.e13wiwn60 > button', 0, 1000, true)
      await tryClick(page, '#loginContainer > div > div > div:nth-child(5)', 0, 1000, true)

      const [main, temp] = await browser.pages()

      await temp.waitForSelector("#identifierId");
      await temp.type("#identifierId", account.email, { delay: 400 });
      await sleep(1000);

      await tryClick(temp, '#identifierNext > div > button > span', 0, 1000, true)

      await temp.waitForSelector("#password");
      await temp.type("#password", account.password, { delay: 400 });
      await sleep(1000);

      await tryClick(temp, '#passwordNext > div > button > div.VfPpkd-RLmnJb', 0, 1000, true)
    }

    if (config.createTiktokWithGoogle)
    {
      await sleep(1000);
      await proxyloader(page, 'http://virusvirulent:PMBB4tfgw3tRjw_country-fr_session-gphf2oze_lifetime-24h_streaming-1@'+'geo.iproyal.com'+':'+'12321');

      await sleep(1000);
      await page.goto("https://www.tiktok.com/")

      await tryClick(page, '#login-modal > div.tiktok-unxpj7-DivCloseWrapper.e1gjoq3k4 > svg', 0)
      await tryClick(page, 'document.querySelector("body > tiktok-cookie-banner").shadowRoot.querySelector("div > div.button-wrapper > button:nth-child(2)")', 1)

      await tryClick(page, '#app > div.tiktok-xk7ai4-DivHeaderContainer.e10win0d0 > div > div.tiktok-ba55d9-DivHeaderRightContainer.e13wiwn60 > button', 0, 1000, true)
      /*await tryClick(page, '#loginContainer > div > div > div:nth-child(5)', 0, 1000, true)

      const [main, temp] = await browser.pages()

      await temp.waitForSelector("#identifierId");
      await temp.type("#identifierId", account.email, { delay: 400 });
      await sleep(1000);

      await tryClick(temp, '#identifierNext > div > button > span', 0, 1000, true)

      await temp.waitForSelector("#password");
      await temp.type("#password", account.password, { delay: 400 });
      await sleep(1000);

      await tryClick(temp, '#passwordNext > div > button > div.VfPpkd-RLmnJb', 0, 1000, true)*/
    }
    
    await page.waitForTimeout(1000)

    await page.close()
    await deadAccount.close()

    await browser.close()

    python.kill();
  }

  return page;
}

main()